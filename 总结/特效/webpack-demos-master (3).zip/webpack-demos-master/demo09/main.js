document.write('<h1>Hello World</h1>');

if (__DEV__) {
  document.write(new Date());
}
