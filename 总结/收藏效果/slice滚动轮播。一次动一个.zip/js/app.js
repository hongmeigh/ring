	$(document).ready(function() {
		$('.content2_item').on('mouseover',function(){
			$(this).find('.content2_item_title').css({'color':'#ffffff','border-bottom-color':'#ffffff'});	
			$(this).find('.content2_item_link a').css({'color':'#ffffff'});
			$('.content2_show_item').hide();
			$(this).find('.content2_show_item').show();
		});
		$('.content2_item').on('mouseout',function(){
			$(this).find('.content2_item_title').css({'color':'#819fdd','border-bottom-color':'#5280e0'});	
			$(this).find('.content2_item_link a').css({'color':'#ff6d94'});
			$(this).find('.content2_show_item').hide();
		});
		
		
		$('.content3_select_content ul').each(function(index, elm) {
            $(elm).find('.select_item').bind('click',function(){
				$(elm).find('.select_item').removeClass('select_val');
				$(this).addClass('select_val');	
			})
        });
		
		$(".fixed-zai").on("click",function(){
			$(".hide-wusan").show();
		});
		$(".hide-wusan img").on("click",function(){
			$(".hide-wusan").hide();
		});
		
		CorrectVal(1);
		CorrectVal(2);
		CorrectVal(3);
		CorrectVal(4);
		CorrectVal(5);
		
		
		
		$('.zhan_miji .teacher_item').on('click',function(){
			$('.zhan_miji .teacher_item .arrow').hide();
			$(this).find('.arrow').show();
			var id=$(this).attr('data-item');
			$('.zhan_miji .teacher_desc_content .teacher_desc').hide();
			$('.zhan_miji .teacher_desc_content .teacher_desc'+id+'').show();
		});
		
		
		$(".carousel-no-style").jCarouselLite({
            btnNext: ".next-no-style",
            btnPrev: ".prev-no-style",
			visible:"4",
        });
		$("#part1").on("click",function(){
        	$("html,body").animate({scrollTop:$(".part1").offset().top-$('.nav').height()-77},500);
    	});
		$("#part2").on("click",function(){
        	$("html,body").animate({scrollTop:$(".part2").offset().top-$('.nav').height()-77},500);
    	});
		$("#part3").on("click",function(){
        	$("html,body").animate({scrollTop:$(".part3").offset().top-$('.nav').height()-77},500);
    	});
		
		
		
		
		  
		var top =$(window).scrollTop();
		if(top>$(".head").height()/2+80)
		{	
			$('.container .side .side_content').show().css({'position':'fixed','top':'280px'});
		}
		
		$(window).scroll(function(e) {
            var top =$(window).scrollTop(); 
			
		    if(top>417)
			{	
				$('.container .side .side_content').show().css({'position':'fixed','top':'280px'});
			}
			
			if(top<417)
			{	
				$('.container .side .side_content').hide().css({'position':'absolute'});
			}
			
			if(top>$(".banner").height())
			{	
				$('.nav').css({'position':'fixed','top':'0px','z-index':'99999999'});
			}
			else
			{	
				$('.nav').css({'position':'relative'});
			}
        });
		
		$('.container .side').height($('.container').height());
		//$('.container .side .side_content').css('top',$(".head").height()+20);
		
		$('.side .side_content .side_item').on('mouseover',function(){
			$('.side .side_content .side_item').removeClass('curren_side');
			$(this).find('.side_item_text').addClass('curren_side');
			$('.side .side_content .side_item .side_show_item').hide();
			$(this).find('.side_show_item').show();
		});
		$('.side .side_content .side_item').on('mouseout',function(){
			$('.side .side_content .side_item .side_item_text').removeClass('curren_side');
			$('.side .side_content .side_item .side_show_item').hide();
		});
		
		$('.video_content').on('mouseover',function(){
			$(this).find('.play_btn').attr('src','img/play_btn2.png');	
		});
		
		$('.video_content').on('mouseout',function(){
			$(this).find('.play_btn').attr('src','img/play_btn1.png');	
		});
		
		
	});
	